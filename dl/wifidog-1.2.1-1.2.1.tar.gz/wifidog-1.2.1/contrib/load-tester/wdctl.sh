#!/bin/bash

while true; do
    ../../src/wdctl status
    sleep 5
done
